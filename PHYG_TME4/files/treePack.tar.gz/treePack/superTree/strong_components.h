#ifndef STRONG_H
#define STRONG_H

#include <GTL/graph.h>
#include <GTL/node_map.h>
#include <stack>

int STRONG_COMPONENTS(const graph& G, node_map<int>& compnum);


#endif

